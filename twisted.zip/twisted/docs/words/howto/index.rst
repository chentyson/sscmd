
:LastChangedDate: $LastChangedDate$
:LastChangedRevision: $LastChangedRevision$
:LastChangedBy: $LastChangedBy$

Developer Guides
========================

.. toctree::
   :hidden:

   im
   ircclient
   ircserverclientcomm


- :doc:`Twisted IM <im>`
- IRC


  - :doc:`Using the Twisted Words IRC client <ircclient>`
  - :doc:`IRC Servers: Communicating With Clients <ircserverclientcomm>`
